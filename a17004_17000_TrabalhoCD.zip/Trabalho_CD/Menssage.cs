﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    public class Menssage
    {
        public string Data { get; set; }

        public Menssage(string data)
        {
            Data = data;
        }

        public Menssage(byte[] data)
        {
            int nameLength = BitConverter.ToInt32(data, 3);
            Data = Encoding.ASCII.GetString(data, 7, nameLength);
        }

        public byte[] ToByteArray()
        {
            List<byte> byteList = new List<byte>();
            
            byteList.AddRange(BitConverter.GetBytes(Data.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(Data));
           
            return byteList.ToArray();
        }
    }
}
