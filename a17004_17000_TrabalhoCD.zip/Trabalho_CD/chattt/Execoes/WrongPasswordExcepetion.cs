﻿using System;
using System.Runtime.Serialization;

namespace Chat.Autenticacao
{
    [Serializable]
    internal class WrongPasswordExcepetion : Exception
    {
        public WrongPasswordExcepetion()
        {
        }

        public WrongPasswordExcepetion(string message) : base(message)
        {
        }

        public WrongPasswordExcepetion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected WrongPasswordExcepetion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}