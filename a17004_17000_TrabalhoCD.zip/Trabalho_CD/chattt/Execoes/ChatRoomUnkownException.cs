﻿using System;
using System.Runtime.Serialization;

namespace Chat.Chat
{
    [Serializable]
    internal class ChatRoomUnkownException : Exception
    {
        public ChatRoomUnkownException()
        {
        }

        public ChatRoomUnkownException(string message) : base(message)
        {
        }

        public ChatRoomUnkownException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ChatRoomUnkownException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}