﻿using System;
using System.Runtime.Serialization;

namespace Chat.Chat
{
    [Serializable]
    internal class ChatRoomAlreadyExist : Exception
    {
        public ChatRoomAlreadyExist()
        {
        }

        public ChatRoomAlreadyExist(string message) : base(message)
        {
        }

        public ChatRoomAlreadyExist(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ChatRoomAlreadyExist(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}