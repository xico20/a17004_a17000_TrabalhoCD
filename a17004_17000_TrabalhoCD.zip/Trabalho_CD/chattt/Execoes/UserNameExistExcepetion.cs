﻿using System;
using System.Runtime.Serialization;

namespace Chat.Autenticacao
{
    [Serializable]
    internal class UserNameExistExcepetion : Exception
    {
        private object usermane;

        public UserNameExistExcepetion()
        {
        }

        public UserNameExistExcepetion(object usermane)
        {
            this.usermane = usermane;
        }

        public UserNameExistExcepetion(string message) : base(message)
        {
        }

        public UserNameExistExcepetion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UserNameExistExcepetion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}