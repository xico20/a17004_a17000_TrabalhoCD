﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace Chat.Autenticacao
{
    public class Seccao 
    {
        string token;
        User user;
        TcpClient client;

        public string Token
        {
            get { return token; }

            set { token = value; }
        }

        public User User
        {
            get { return User; }

            set { User = value; }
        }

        public TcpClient Client
        {
            get { return Client; }

            set { Client = value; }
        }

        public Seccao()
        {
            this.Client = null;
            this.User = null;
        }

    }
}
