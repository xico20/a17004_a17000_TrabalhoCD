﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chat.Autenticacao
{
    class UserM
    {
        List<User> userL;

        public List<User> UserL
        {
            get { return userL; }

            set { userL = value; }
        }

        public UserM()
        {
            userL = new List<User>();
        }
    
        public void AddUser(string username, string password)
        {
            foreach(User u in UserL.ToList())
            {
                if (u.Username == username)
                {
                    throw new UserNameExistExcepetion(username);
                }
            }

            UserL.Add(new User(username, password));
        }

        public void RemoveUser(string s)
        {
            User userDelete = null;

            foreach (User u in UserL.ToList())
            {
                if (u.Username == s)
                {
                    userDelete = u;
                }
            }

            if (userDelete == null)
            {
                throw new UserUnknownException(s);
            }

            UserL.Remove(userDelete);
        }
    
        public void Autenticar(string username, string password)
        {
            User userAutenticacao = null;

            foreach (User u in UserL.ToList())
            {
                if (u.Username == username && u.Password == password)
                {
                    userAutenticacao = u;
                }
            }

            if (userAutenticacao == null)
            {
                throw new WrongPasswordExcepetion(username);
            }
        }

        public void load(string path)
        {
            try
            {
                using (Stream stream = File.Open(path, FileMode.Open))
                {
                    BinaryFormatter bin = new BinaryFormatter();
                    List<User> users = (List<User>)bin.Deserialize(stream);
                    userL = users;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
