﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;


namespace Chat.Autenticacao
{
    public class SeccaoM 
    {
        List<Seccao> seccaoL;

        public List<Seccao> SeccaoL
        {
            get { return seccaoL; }

            set { seccaoL = value; }
        }

        public SeccaoM()
        {
            SeccaoL = new List<Seccao>();
        }
    
        public void AddSeccao(Seccao s)
        {
            //condicao 
            SeccaoL.Add(s);
        }
    
        public void RemoveSeccao(string s)
        {
            Seccao seccaoDelete = null;

            foreach(Seccao session in SeccaoL.ToList())
            {
                if (session.Token == s)
                {
                    seccaoDelete = session;
                }
            }

            if (seccaoDelete == null)
            {
                throw new SessionUnknowExcepetion(s);
            }

            SeccaoL.Remove(seccaoDelete);
        } 
    }
}
