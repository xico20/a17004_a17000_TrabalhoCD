﻿using System;
using System.Runtime.Serialization;

namespace Chat.Autenticacao
{
    [Serializable]
    internal class SessionUnknowExcepetion : Exception
    {
        private Seccao s;

        public SessionUnknowExcepetion()
        {
        }

        public SessionUnknowExcepetion(Seccao s)
        {
            this.s = s;
        }

        public SessionUnknowExcepetion(string message) : base(message)
        {
        }

        public SessionUnknowExcepetion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SessionUnknowExcepetion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}