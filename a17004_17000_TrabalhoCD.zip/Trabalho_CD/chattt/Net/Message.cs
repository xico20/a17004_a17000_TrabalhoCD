﻿using System;
using System.Collections.Generic;

namespace Chat.Net
{
    [Serializable]
    public class Message
    {
        private List<string> messageList;

        public List<string> MessageList
        {
            get{ return messageList; }

            set{ messageList = value; }
        }

        public Message(string message)
        {
            this.MessageList = new List<string>();
            this.MessageList.Add(message);
        }

        public void addData(string message)
        {
            this.MessageList.Add(message);
        }
    }
}
