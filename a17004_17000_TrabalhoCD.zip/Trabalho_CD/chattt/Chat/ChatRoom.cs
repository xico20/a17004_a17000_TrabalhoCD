﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chat.Chat
{
    [Serializable]
    public class ChatRoom : IComparable<ChatRoom>
    {
        string username;

        public string Username
        {
            get { return username; }

            set { username = value; }
        }
    
        public ChatRoom(string username)
        {
            this.username = username;
        }
    
        
    }
}
