﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chat.Chat
{
    [Serializable]
    public class ChatRoomM
    {
        List<ChatRoom> chatRoomList;

        public List<ChatRoom> ChatRoomL
        {
            get { return chatRoomList; }

            set { chatRoomList = value; }
        }

        public ChatRoomM()
        {
            ChatRoomL = new List<ChatRoom>();
        }
    
        public void AddRoom(ChatRoom room)
        {
            foreach (ChatRoom c in ChatRoomL.ToList())
            {
                if (c.Username == room.Username)
                {
                    throw new ChatRoomAlreadyExist(c.Username);
                }
            }

            chatRoomList.Add(room);        
        }
    
        public void RemoveRoom(string s)
        {
            ChatRoom chatRoomRemove = null;

            foreach(ChatRoom c in chatRoomList.ToList())
            {
                if (c.Username == s)
                {
                    chatRoomRemove = c;
                }
            }

            if (chatRoomRemove == null)
            {
                throw new ChatRoomUnkownException(s);
            }

            chatRoomList.Remove(chatRoomRemove);
        }
    }
}
