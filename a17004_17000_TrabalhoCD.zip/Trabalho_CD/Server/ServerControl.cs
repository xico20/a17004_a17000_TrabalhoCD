﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server
{
    public class ServerControl
    {
        public void StartServer()
        {
            UdpClient udpClient = new UdpClient();

            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Broadcast, 8000);

            for (; ; )
            {
                string message1;
                Console.WriteLine("Write message");
                message1 = Console.ReadLine();
                Console.WriteLine("");
                string message = message1;
                byte[] buffer = new byte[2000];
                buffer = ASCIIEncoding.ASCII.GetBytes(message);
                udpClient.Send(buffer, buffer.Length, ipEndPoint);
            }

        }
    }
}
