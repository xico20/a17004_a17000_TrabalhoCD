﻿using System;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Input;
using System.Text;
using System.Net.Sockets;

namespace Trabalho_CD
{
    public partial class Main : Form
    {

        Thread t, t1;
        UserMang userMang = new UserMang();
        ICommand command;

        private Socket clientSocket;
        private byte[] buffer;

        public Main()
        {
            InitializeComponent();

            comboBox1.Items.Add("Estudante");
            comboBox1.Items.Add("Docente");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void AbrirChat(object obj)
        {
            Application.Run(new Chat());
        }

        private void loginB2_Click(object sender, EventArgs e)
        {
            User user = new User(usernameT.Text, passwordT.Text);

            try
            {
                //user.FazerLogin(passwordR.Text, usernameR.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            this.Close();
            t = new Thread(AbrirChat);
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
        }

        private void registarB_Click(object sender, EventArgs e)
        {
            object type = comboBox1.SelectedItem;
            string aux = comboBox1.SelectedItem.ToString();
            User.type tipo = new User.type();

            if (aux == "Estudante")
            {
                tipo = User.type.estudante;
            }
            if (aux == "Docente")
            {
                tipo = User.type.docente;
            }
            if (this.comboBox1.SelectedItem == null )
            {
                throw new NoItemSelectedException();
            }
            
            User user = new User(usernameR.Text, passwordR.Text, tipo);
            
            try
            {
                command = userMang.AddUserCommand;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            this.Close();
            t1 = new Thread(AbrirChat);
            t1.SetApartmentState(ApartmentState.STA);
            t1.Start();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
