﻿namespace Trabalho_CD
{
    partial class Chat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sairBt = new System.Windows.Forms.Button();
            this.enviarBt = new System.Windows.Forms.Button();
            this.mensagemTx = new System.Windows.Forms.TextBox();
            this.chatTx = new System.Windows.Forms.ListBox();
            this.serverIPT = new System.Windows.Forms.TextBox();
            this.clientIPT = new System.Windows.Forms.TextBox();
            this.startBt = new System.Windows.Forms.Button();
            this.conectBt = new System.Windows.Forms.Button();
            this.serverIP = new System.Windows.Forms.Label();
            this.clientIP = new System.Windows.Forms.Label();
            this.serverP = new System.Windows.Forms.TextBox();
            this.clientP = new System.Windows.Forms.TextBox();
            this.serverPort = new System.Windows.Forms.Label();
            this.ClientPort = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // sairBt
            // 
            this.sairBt.Location = new System.Drawing.Point(603, 410);
            this.sairBt.Name = "sairBt";
            this.sairBt.Size = new System.Drawing.Size(75, 23);
            this.sairBt.TabIndex = 0;
            this.sairBt.Text = "Sair";
            this.sairBt.UseVisualStyleBackColor = true;
            this.sairBt.Click += new System.EventHandler(this.sairBt_Click);
            // 
            // enviarBt
            // 
            this.enviarBt.Location = new System.Drawing.Point(489, 405);
            this.enviarBt.Name = "enviarBt";
            this.enviarBt.Size = new System.Drawing.Size(75, 23);
            this.enviarBt.TabIndex = 1;
            this.enviarBt.Text = "Enviar";
            this.enviarBt.UseVisualStyleBackColor = true;
            this.enviarBt.Click += new System.EventHandler(this.enviarBt_Click);
            // 
            // mensagemTx
            // 
            this.mensagemTx.Location = new System.Drawing.Point(96, 405);
            this.mensagemTx.Name = "mensagemTx";
            this.mensagemTx.Size = new System.Drawing.Size(366, 22);
            this.mensagemTx.TabIndex = 2;
            // 
            // chatTx
            // 
            this.chatTx.FormattingEnabled = true;
            this.chatTx.ItemHeight = 16;
            this.chatTx.Location = new System.Drawing.Point(96, 169);
            this.chatTx.Name = "chatTx";
            this.chatTx.Size = new System.Drawing.Size(468, 212);
            this.chatTx.TabIndex = 3;
            this.chatTx.SelectedIndexChanged += new System.EventHandler(this.chatTx_SelectedIndexChanged);
            // 
            // serverIPT
            // 
            this.serverIPT.Location = new System.Drawing.Point(232, 48);
            this.serverIPT.Name = "serverIPT";
            this.serverIPT.Size = new System.Drawing.Size(100, 22);
            this.serverIPT.TabIndex = 4;
            this.serverIPT.TextChanged += new System.EventHandler(this.serverIPT_TextChanged);
            // 
            // clientIPT
            // 
            this.clientIPT.Location = new System.Drawing.Point(232, 105);
            this.clientIPT.Name = "clientIPT";
            this.clientIPT.Size = new System.Drawing.Size(100, 22);
            this.clientIPT.TabIndex = 5;
            // 
            // startBt
            // 
            this.startBt.Location = new System.Drawing.Point(567, 44);
            this.startBt.Name = "startBt";
            this.startBt.Size = new System.Drawing.Size(75, 23);
            this.startBt.TabIndex = 6;
            this.startBt.Text = "Start";
            this.startBt.UseVisualStyleBackColor = true;
            this.startBt.Click += new System.EventHandler(this.startBt_Click);
            // 
            // conectBt
            // 
            this.conectBt.Location = new System.Drawing.Point(567, 104);
            this.conectBt.Name = "conectBt";
            this.conectBt.Size = new System.Drawing.Size(75, 23);
            this.conectBt.TabIndex = 7;
            this.conectBt.Text = "Connect";
            this.conectBt.UseVisualStyleBackColor = true;
            this.conectBt.Click += new System.EventHandler(this.conectBt_Click);
            // 
            // serverIP
            // 
            this.serverIP.AutoSize = true;
            this.serverIP.Location = new System.Drawing.Point(160, 51);
            this.serverIP.Name = "serverIP";
            this.serverIP.Size = new System.Drawing.Size(66, 17);
            this.serverIP.TabIndex = 8;
            this.serverIP.Text = "Server IP";
            // 
            // clientIP
            // 
            this.clientIP.AutoSize = true;
            this.clientIP.Location = new System.Drawing.Point(167, 105);
            this.clientIP.Name = "clientIP";
            this.clientIP.Size = new System.Drawing.Size(59, 17);
            this.clientIP.TabIndex = 9;
            this.clientIP.Text = "Client IP";
            // 
            // serverP
            // 
            this.serverP.Location = new System.Drawing.Point(445, 47);
            this.serverP.Name = "serverP";
            this.serverP.Size = new System.Drawing.Size(100, 22);
            this.serverP.TabIndex = 10;
            // 
            // clientP
            // 
            this.clientP.Location = new System.Drawing.Point(445, 105);
            this.clientP.Name = "clientP";
            this.clientP.Size = new System.Drawing.Size(100, 22);
            this.clientP.TabIndex = 11;
            // 
            // serverPort
            // 
            this.serverPort.AutoSize = true;
            this.serverPort.Location = new System.Drawing.Point(359, 50);
            this.serverPort.Name = "serverPort";
            this.serverPort.Size = new System.Drawing.Size(80, 17);
            this.serverPort.TabIndex = 12;
            this.serverPort.Text = "Server Port";
            // 
            // ClientPort
            // 
            this.ClientPort.AutoSize = true;
            this.ClientPort.Location = new System.Drawing.Point(366, 108);
            this.ClientPort.Name = "ClientPort";
            this.ClientPort.Size = new System.Drawing.Size(73, 17);
            this.ClientPort.TabIndex = 13;
            this.ClientPort.Text = "Client Port";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork);
            // 
            // Chat
            // 
            this.ClientSize = new System.Drawing.Size(690, 454);
            this.Controls.Add(this.ClientPort);
            this.Controls.Add(this.serverPort);
            this.Controls.Add(this.clientP);
            this.Controls.Add(this.serverP);
            this.Controls.Add(this.clientIP);
            this.Controls.Add(this.serverIP);
            this.Controls.Add(this.conectBt);
            this.Controls.Add(this.startBt);
            this.Controls.Add(this.clientIPT);
            this.Controls.Add(this.serverIPT);
            this.Controls.Add(this.chatTx);
            this.Controls.Add(this.mensagemTx);
            this.Controls.Add(this.enviarBt);
            this.Controls.Add(this.sairBt);
            this.Name = "Chat";
            this.Load += new System.EventHandler(this.Chat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sairB;
        //private System.Windows.Forms.TextBox mensagemT;
        private System.Windows.Forms.Button enviarB;
        private System.Windows.Forms.ListBox chatT;
        private System.Windows.Forms.TextBox servidorIPT;
        private System.Windows.Forms.TextBox userT;
        private System.Windows.Forms.Label servidorIP;
        private System.Windows.Forms.Label user;
        private System.Windows.Forms.Button sairBt;
        private System.Windows.Forms.Button enviarBt;
        private System.Windows.Forms.TextBox mensagemTx;
        private System.Windows.Forms.ListBox chatTx;
        private System.Windows.Forms.TextBox serverIPT;
        private System.Windows.Forms.TextBox clientIPT;
        private System.Windows.Forms.Button startBt;
        private System.Windows.Forms.Button conectBt;
        private System.Windows.Forms.Label serverIP;
        private System.Windows.Forms.Label clientIP;
        private System.Windows.Forms.TextBox serverP;
        private System.Windows.Forms.TextBox clientP;
        private System.Windows.Forms.Label serverPort;
        private System.Windows.Forms.Label ClientPort;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
    }
}