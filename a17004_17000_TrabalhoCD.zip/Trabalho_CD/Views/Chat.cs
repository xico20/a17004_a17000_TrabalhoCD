﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using System.ComponentModel;
using Server;

namespace Trabalho_CD
{
    public partial class Chat : Form
    {
        
        Thread t;
        private TcpClient client;
        public StreamReader STR;
        public StreamWriter STW;
        public string receive;
        public string TextToSend;

        private Socket clientSocket;
        private byte[] buffer;

        public Chat()
        {
            InitializeComponent();

            IPAddress[] localIp = Dns.GetHostAddresses(Dns.GetHostName());

            foreach (IPAddress address in localIp)
            {
                if (address.AddressFamily == AddressFamily.InterNetwork)
                {
                    serverIPT.Text = address.ToString();
                    clientIPT.Text = address.ToString();
                    serverP.Text = "8000";
                    clientP.Text = "8000";
                }
            }
        }

        #region sair para menu
        private void sairBt_Click(object sender, EventArgs e)
        {
            this.Close();
            t = new Thread(CloseChat);
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
        }

        private void CloseChat (object o)
        {
            Application.Run(new Main());     
        }
        #endregion

        private void enviarBt_Click(object sender, EventArgs e)
        {
            client = new TcpClient();
            if (mensagemTx.Text != "")
            {
                if (client.Connected)
                {
                    Menssage message = new Menssage(mensagemTx.Text);
                    byte[] buffer = message.ToByteArray();
                    clientSocket.BeginSend(buffer, 0, buffer.Length, SocketFlags.None, SendCallback, null);
                }
                else Console.Beep();
                //TextToSend = mensagemTx.Text;
                //backgroundWorker2.RunWorkerAsync();
            }
         
            mensagemTx.Text = "";
        }

        private void chatTx_SelectedIndexChanged(object sender, EventArgs e)
        {
            //udpClient.EnableBroadcast = false;
            //udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            //udpClient.EnableBroadcast = false;
            //udpClient.Client.Bind(ipEndPoint);

            //Byte[] data = udpClient.Receive(ref ipEndPoint);
            //string stringData = Encoding.ASCII.GetString(data);
            //chatT.Items.Add("Friend: " + mensagemT.Text);
            //mensagemT.Clear();
        }

        private void startBt_Click(object sender, EventArgs e)
        {
            TcpListener listener = new TcpListener(IPAddress.Parse(serverIPT.Text), int.Parse(serverP.Text));
           
            listener.Start();
            
            try {
                client = listener.AcceptTcpClient();
                STR = new StreamReader(client.GetStream());
                STW = new StreamWriter(client.GetStream());

                STW.AutoFlush = true;

                backgroundWorker1.RunWorkerAsync();
                backgroundWorker2.WorkerSupportsCancellation = true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void conectBt_Click(object sender, EventArgs e)
        { 
            try
            {
                clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                // Connect to the specified host.
                var endPoint = new IPEndPoint(IPAddress.Parse(clientIPT.Text), 8000);
                clientSocket.BeginConnect(endPoint, ConnectCallback, null);
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            catch (ObjectDisposedException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            //client = new TcpClient();
            //IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse(clientIPT.Text), int.Parse(clientP.Text));

            //try
            //{
            //    client.Connect(ipEnd);
            //    if (client.Connected)
            //    {
            //        chatTx.Items.Add("Connected to server");
            //        STR = new StreamReader(client.GetStream());
            //        STW = new StreamWriter(client.GetStream());

            //        STW.AutoFlush = true;

            //        backgroundWorker1.RunWorkerAsync();
            //        backgroundWorker2.WorkerSupportsCancellation = true;
            //    }
            //}
            //catch(Exception ex)
            //{
            //    MessageBox.Show(ex.Message.ToString());
            //}
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (client.Connected)
            {
                try
                {
                    receive = STR.ReadLine();
                    this.chatTx.Invoke(new MethodInvoker(delegate ()
                    {
                        chatTx.Items.Add("You: " + receive);
                    }));
                    receive = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            if (client.Connected)
            {
                STW.WriteLine(TextToSend);
                this.chatTx.Invoke(new MethodInvoker(delegate
                {
                    chatTx.Items.Add("Me: " + TextToSend);
                }));
            }
            else
            {
                throw new ErrorSendMessageException();
            }

            backgroundWorker2.CancelAsync();
        }

        private void serverIPT_TextChanged(object sender, EventArgs e)
        {

        }

        private void Chat_Load(object sender, EventArgs e)
        {

        }

        private void ReceiveCallback(IAsyncResult AR)
        {
            try
            {
                int received = clientSocket.EndReceive(AR);

                if (received == 0)
                {
                    return;
                }


                string message = Encoding.ASCII.GetString(buffer);

                Invoke((Action)delegate
                {
                    Text = "Server says: " + message;
                });

                // Start receiving data again.
                clientSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, ReceiveCallback, null);
            }
            // Avoid Pokemon exception handling in cases like these.
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            catch (ObjectDisposedException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void ConnectCallback(IAsyncResult AR)
        {
            try
            {
                clientSocket.EndConnect(AR);
                buffer = new byte[clientSocket.ReceiveBufferSize];
                clientSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, ReceiveCallback, null);
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            catch (ObjectDisposedException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void SendCallback(IAsyncResult AR)
        {
            try
            {
                clientSocket.EndSend(AR);
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            catch (ObjectDisposedException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        
    }
}
