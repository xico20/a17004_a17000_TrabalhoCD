﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Trabalho_CD
{
    public class ClientControl
    {
        public void StartClient()
        {
            UdpClient udpClient = new UdpClient();

            udpClient.EnableBroadcast = false;
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Any, 8000);
            udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            udpClient.EnableBroadcast = false;
            
            udpClient.Client.Bind(ipEndPoint);

            for (; ; )
            {
                Byte[] data = udpClient.Receive(ref ipEndPoint);
                string stringData = Encoding.ASCII.GetString(data);
                Console.WriteLine(stringData);
            }
        }
    }
}
