﻿using System;

namespace Trabalho_CD
{
    [Serializable]
    public class User
    {

        public static string username, password;
        public enum type
        {
            estudante = 0,
            docente = 1
        }

        public string Username
        {
            get { return username; }

            set { username = value; }
        }

        public string Password
        {
            get { return password; }

            set { password = value; }
        }

        public type tipo { get; set; }

        public User(string Username, string Password, type tipo)
        {
            username = Username;
            password = Password;
            this.tipo = tipo;
        }
        
        public User(string Username, string Password)
        {
            username = Username;
            password = Password;
        }
    
        public User()
        {

        }
    }
}
