﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_CD
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Main());
            //ClientControl clientControl = new ClientControl();
            //clientControl.StartClient();
            //UserMang clienteMang = new UserMang();
            //clienteMang.Start();
            //User user = new User();
            //user.Start();
        }
    }
}
