﻿using System;
using System.Runtime.Serialization;

namespace Trabalho_CD
{
    [Serializable]
    internal class UserNotFoundExcepetion : Exception
    {
        public UserNotFoundExcepetion()
        {
        }

        public UserNotFoundExcepetion(string message) : base(message)
        {
        }

        public UserNotFoundExcepetion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UserNotFoundExcepetion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}