﻿using System;
using System.Runtime.Serialization;

namespace Trabalho_CD
{
    [Serializable]
    internal class ErrorSendMessageException : Exception
    {
        public ErrorSendMessageException()
        {
        }

        public ErrorSendMessageException(string message) : base(message)
        {
        }

        public ErrorSendMessageException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ErrorSendMessageException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}