﻿using GalaSoft.MvvmLight.Command;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Input;

namespace Trabalho_CD
{
    [Serializable]
    public class UserMang
    {

        private TcpListener _tcpListener;
        private List<TcpClient> _tcpClients;
        private TcpClient tcpClient;
        public static string username { get; set; }
        public static string password { get; set; }
        public static User.type tipo;
        public static ObservableCollection<User> UserObservable;

        public ICommand AddUserCommand { get; set; }
        public ICommand LoginCommand { get; set; }
       
        public UserMang()
        {
            AddUserCommand = new RelayCommand(AddUserAction);
            LoginCommand = new RelayCommand(LoginAction);
        }

        public void Start()
        {
            _tcpClients = new List<TcpClient>();
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Any, 15000);
            _tcpListener = new TcpListener(ipEndPoint);
            _tcpListener.Start();
            Thread acceptTcpClientThread = new Thread(AcceptTcpClient);
            acceptTcpClientThread.Start();
            Thread processNetworkStreamsThread = new Thread(ProcessNetworkStreams);
            processNetworkStreamsThread.Start();
        }

        public void AcceptTcpClient()
        {
            while (true)
            {
                try
                {
                    TcpClient client = _tcpListener.AcceptTcpClient();
                    _tcpClients.Add(client);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.WriteLine(ex.Message);
                }
            }

        }

        public void ProcessNetworkStreams()
        {
            try
            {
                username = User.username;
                password = User.password;
                NetworkStream networkStream = tcpClient.GetStream();
                Thread.Sleep(1000);
                User user = new User(username, password, tipo);
                string jsonString = JsonConvert.SerializeObject(user);
                Byte[] data = Encoding.ASCII.GetBytes(jsonString);
                networkStream.Write(data, 0, data.Length);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine(ex.Message);
                _tcpClients.Remove(tcpClient);
            }
        }

        private void AddUserAction()
        {
            int count = UserObservable.Count;
            
            User usuario = new User()
            {
                Username = username,
                Password = password,
                tipo = tipo
            };

            for (int i = 0; i < count; i++)
            {
                if (UserObservable.Contains(usuario))   
                {
                    throw new UserAlreadyExistException();
                }
            }

            UserObservable.Add(usuario);
        }

        private void LoginAction()
        {
            int count = UserObservable.Count;

            User user = new User();

            for (int i = 0; i < count; i++)
            {
                if (UserObservable.Contains(user))
                {
                    continue;
                }
                else
                {
                    throw new UserNotFoundExcepetion();
                }
            }    
        }

        #region lixo
        //public int CriarConta(User user)
        //{
        //    IPAddress[] localIp = Dns.GetHostAddresses(Dns.GetHostName());
        //    TcpClient client;
        //    NetworkStream ns;
        //    string jsonString;
        //    Byte[] data;

        //    string localIP = localIp.ToString();
        //    //client = new TcpClient(new IPEndPoint(IPAddress.Parse(localIP), 9000));
        //    client = new TcpClient(new IPEndPoint(IPAddress.Parse("192.168.1.77"), 9000));
        //    ns = client.GetStream();
        //    jsonString = JsonConvert.SerializeObject(user);
        //    data = Encoding.ASCII.GetBytes(jsonString);
        //    ns.Write(data, 0, data.Length);

        //    return 1;
        //}
        //
        //public bool FazerLogin(string username, string password)
        //{
        //    IPAddress[] localIp = Dns.GetHostAddresses(Dns.GetHostName());
        //    TcpClient client;
        //    NetworkStream stream;
        //    byte[] data;
        //    string localIP = localIp.ToString();


        //    //client = new TcpClient(new IPEndPoint(IPAddress.Parse(localIP), 9000));
        //    client = new TcpClient(new IPEndPoint(IPAddress.Parse("192.168.1.77"), 9000));
        //    stream = client.GetStream();
        //    data = new byte[1024];

        //    do
        //    {
        //        if (stream.CanRead)
        //        {
        //            if (data == Encoding.ASCII.GetBytes(username + password + (true || false)))
        //            {
        //                return true;
        //            }
        //        }

        //        return false;

        //    } while (stream.DataAvailable);
        //}
        #endregion
    }
}
